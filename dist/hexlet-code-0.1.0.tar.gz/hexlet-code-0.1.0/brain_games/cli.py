from brain_games.logic.constants import NAME


def hello_user():
    print(f'Hello, {NAME}!')
    

