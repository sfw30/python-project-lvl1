#!/usr/bin/env python
from brain_games import cli


def main():
	cli.run()


if __name__ == '__main__':
	main()