import prompt


NAME = prompt.string('May I have your name? ')