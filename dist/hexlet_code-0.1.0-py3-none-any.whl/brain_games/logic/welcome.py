import prompt


def welcome_text():
	print('Welcome to the Brain Games!')


welcome_text()


if __name__ == '__main__':
	welcome_text()
